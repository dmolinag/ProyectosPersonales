# arduinesp
Arduino ESP8266. Running Arduino on an ESP8266 using the Arduino IDE

If you have wondered, if is it possible run your sketch on the ESP8266 program like you did on your arduino UNO board. 
Yes it is possible, without using your UNO board. Just download the setup from www.arduinesp.com and start developing from the familiar Arduino IDE.
Upload your programs direct to ESP8266 your ESP8266 by pressing the button ‘upload’ in Arduino. Use the standard sketches like “blink” or use the basic examples like wifi_blink
Arduino programs running on your ESP8266 a 3 US$ wifi enabled board.

Here on github you will find the source.
If you would like to improve the toolchain, the core or add some examples. Github is the right place.

The easy way to use arduinesp will be starting from the site http://www.arduinesp.com/  

Good luck, and share your knowledge.
